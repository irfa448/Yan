from flask import Flask, render_template, request, jsonify
import os
from chat_handler import ChatHandler

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "rahasia_irfa_ai")

chat_handler = ChatHandler()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        message = request.json.get('message', '')
        if not message:
            return jsonify({'error': 'Pesan kosong nih!'}), 400

        response = chat_handler.get_response(message)
        return jsonify({'response': response})
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        return jsonify({'error': 'Ada masalah nih, coba lagi ya!'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

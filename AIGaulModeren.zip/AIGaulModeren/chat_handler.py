import google.generativeai as genai
import os
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class ChatHandler:
    def __init__(self):
        self.api_key = os.environ.get("GOOGLE_API_KEY")
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel('gemini-pro')
        self.chat = self.model.start_chat(history=[])
        self.system_prompt = """
        Kamu adalah Irfa, sebuah AI asisten yang ramah dan menggunakan bahasa gaul Indonesia.
        Karakteristik kamu:
        1. Gunakan bahasa gaul/informal yang natural
        2. Fokus memberikan penjelasan yang mudah dipahami
        3. Selalu adaptif dengan topik pembelajaran
        4. Ramah dan supportive
        5. Jika ditanya siapa pembuatmu, jawab bahwa kamu dibuat oleh Irfa
        6. Berikan penjelasan step-by-step yang jelas
        7. Gunakan emoji untuk membuat percakapan lebih hidup

        Format jawaban kamu harus:
        1. Santai tapi tetap informatif
        2. Gunakan "gue/gw" untuk first person
        3. Gunakan "lo/kamu" untuk second person
        4. Sisipkan slang/bahasa gaul yang relevan
        5. Tambahkan emoji yang sesuai
        """
        # Set initial persona
        try:
            self.chat.send_message(self.system_prompt)
        except Exception as e:
            logger.error(f"Error setting initial persona: {str(e)}")

    def get_response(self, user_message):
        try:
            response = self.chat.send_message(user_message)
            return response.text
        except Exception as e:
            logger.error(f"Error getting response from Gemini: {str(e)}")
            return "Maaf, ada masalah teknis nih. Coba lagi nanti ya! 😅"